Welcome to <?php echo e($user->tenant->name ?? config('app.name')); ?>!

Hello <?php echo e($user->name); ?>,

Your account has been created successfully. You can now access the system using the following credentials:

Email: <?php echo e($user->email); ?>

<?php if($password): ?>
Password: <?php echo e($password); ?>


Please change your password after your first login for security.
<?php else: ?>
Please use the password you set during registration.
<?php endif; ?>

Login URL: <?php echo e($loginUrl); ?>


If you have any questions or need assistance, please don't hesitate to contact our support team.

Best regards,
<?php echo e($user->tenant->name ?? config('app.name')); ?> Team

---
This is an automated message. Please do not reply to this email.

























<?php /**PATH C:\xampp\htdocs\ERP\ERPBackend\resources\views/emails/welcome-user-text.blade.php ENDPATH**/ ?>