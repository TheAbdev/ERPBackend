# دليل تفصيلي: Queue Workers و Scheduled Tasks

## 📋 نظرة عامة

عندما تشغل `php artisan queue:work` و `php artisan schedule:work`، يتم تنفيذ المهام التالية:

---

## 🔄 `schedule:work` - المهام المجدولة (Scheduled Tasks)

المهام المجدولة موجودة في: `routes/console.php`

### 1. **`crm:check-activity-reminders`** 
- **التكرار:** كل 5 دقائق
- **الملف:** `app/Console/Commands/CheckActivityReminders.php`
- **الوظيفة:** 
  - يبحث عن الأنشطة (Activities) التي ستكون مستحقة خلال 15 دقيقة
  - يرسل تذكيرات للمستخدمين المعينين
- **الجداول المستخدمة:**
  - `activities` - للبحث عن الأنشطة المستحقة
  - `notifications` - لحفظ الإشعارات
- **يضيف إلى الطابور:**
  - `SendActivityReminderJob` - لإرسال التذكيرات

---

### 2. **`crm:sync-email-accounts`**
- **التكرار:** كل 5 دقائق
- **الملف:** `app/Console/Commands/SyncEmailAccounts.php`
- **الوظيفة:**
  - مزامنة البريد الإلكتروني من حسابات IMAP
  - جلب الرسائل الجديدة من جميع الحسابات النشطة
- **الجداول المستخدمة:**
  - `email_accounts` - حسابات البريد الإلكتروني
  - `emails` - الرسائل المستوردة

---

### 3. **`erp:generate-scheduled-reports`**
- **التكرار:** كل دقيقة
- **الملف:** `app/Console/Commands/GenerateScheduledReports.php`
- **الوظيفة:**
  - يتحقق من التقارير المجدولة (`erp_report_schedules`)
  - يولد التقارير التي حان وقتها
  - يصدر التقارير بصيغ مختلفة (PDF, Excel, CSV)
- **الجداول المستخدمة:**
  - `erp_report_schedules` - جدول التقارير المجدولة
  - `erp_reports` - التقارير نفسها
- **يضيف إلى الطابور:**
  - `ExportReportJob` - لتصدير وإرسال التقارير

---

### 4. **`erp:check-system-health`**
- **التكرار:** كل 5 دقائق
- **الملف:** `app/Console/Commands/CheckSystemHealth.php`
- **الوظيفة:**
  - فحص صحة النظام لجميع المستأجرين (Tenants)
  - مراقبة استخدام CPU، الذاكرة، القرص
  - فحص الاتصالات النشطة وحجم الطابور
- **الجداول المستخدمة:**
  - `system_health` - لحفظ نتائج الفحص
  - `tenants` - قائمة المستأجرين

---

### 5. **`erp-retry-webhook-deliveries`**
- **التكرار:** كل 10 دقائق
- **الملف:** `routes/console.php` (مهمة مباشرة)
- **الوظيفة:**
  - إعادة محاولة إرسال Webhooks الفاشلة
  - البحث عن عمليات التسليم (`webhook_deliveries`) الفاشلة وإعادة محاولتها
- **الجداول المستخدمة:**
  - `erp_webhook_deliveries` - عمليات تسليم Webhooks
  - `erp_webhooks` - إعدادات Webhooks

---

### 6. **`erp:generate-recurring-invoices`**
- **التكرار:** يومياً (Daily)
- **الملف:** `app/Console/Commands/GenerateRecurringInvoices.php`
- **الوظيفة:**
  - توليد الفواتير المتكررة المستحقة
  - إنشاء فواتير جديدة بناءً على الجداول المتكررة
- **الجداول المستخدمة:**
  - `erp_recurring_invoices` - الفواتير المتكررة
  - `erp_invoices` - الفواتير المُنشأة

---

### 7. **`erp:check-reorder-rules`**
- **التكرار:** يومياً (Daily)
- **الملف:** `app/Console/Commands/CheckReorderRules.php`
- **الوظيفة:**
  - فحص قواعد إعادة الطلب (Reorder Rules)
  - إنشاء أوامر شراء تلقائية للمنتجات التي تحتاج إعادة طلب
- **الجداول المستخدمة:**
  - `erp_products` - المنتجات
  - `erp_reorder_rules` - قواعد إعادة الطلب
  - `erp_purchase_orders` - أوامر الشراء المُنشأة

---

## 📦 `queue:work` - المهام في الطابور (Queue Jobs)

المهام في الطابور موجودة في: `app/Jobs/`

### 1. **`DeliverWebhookJob`**
- **الملف:** `app/Jobs/DeliverWebhookJob.php`
- **الوظيفة:**
  - إرسال Webhooks إلى URLs خارجية
  - إرسال بيانات الأحداث (Events) إلى أنظمة خارجية
- **متى يُضاف للطابور:**
  - عند حدوث حدث في النظام (مثل: إنشاء صفقة، تحديث منتج، إلخ)
  - يتم إضافته من `WebhookService::queueDelivery()`
- **الجداول المستخدمة:**
  - `erp_webhook_deliveries` - لتسجيل محاولات التسليم
  - `erp_webhooks` - إعدادات Webhooks

---

### 2. **`ExecuteWorkflowJob`**
- **الملف:** `app/Jobs/ExecuteWorkflowJob.php`
- **الوظيفة:**
  - تنفيذ Workflows تلقائياً
  - تشغيل الإجراءات المحددة عند حدوث أحداث معينة
- **متى يُضاف للطابور:**
  - عند حدوث حدث يطابق Workflow (مثل: إنشاء Lead، تغيير حالة Deal)
  - يتم إضافته من `WorkflowEngineService::trigger()`
- **الجداول المستخدمة:**
  - `workflows` - تعريفات Workflows
  - `workflow_runs` - سجل تنفيذ Workflows
  - `workflow_instances` - حالات Workflows

---

### 3. **`ExportReportJob`**
- **الملف:** `app/Jobs/ExportReportJob.php`
- **الوظيفة:**
  - تصدير التقارير بصيغ مختلفة (PDF, Excel, CSV)
  - إرسال التقارير إلى المستلمين عبر البريد الإلكتروني
- **متى يُضاف للطابور:**
  - من `GenerateScheduledReports` command عند حان وقت تقرير مجدول
  - عند طلب تصدير تقرير يدوياً
- **الجداول المستخدمة:**
  - `erp_report_schedules` - جدول التقارير المجدولة
  - `erp_reports` - التقارير

---

### 4. **`SendActivityReminderJob`**
- **الملف:** `app/Jobs/SendActivityReminderJob.php`
- **الوظيفة:**
  - إرسال تذكيرات للمستخدمين حول الأنشطة المستحقة
  - إرسال إشعارات للمستخدم المعين أو المنشئ
- **متى يُضاف للطابور:**
  - من `CheckActivityReminders` command كل 5 دقائق
  - عند إنشاء نشاط جديد
- **الجداول المستخدمة:**
  - `activities` - الأنشطة
  - `notifications` - الإشعارات

---

### 5. **`SendDealNotificationJob`**
- **الملف:** `app/Jobs/SendDealNotificationJob.php`
- **الوظيفة:**
  - إرسال إشعارات عند تغيير حالة الصفقة
  - إشعار المستخدم المعين والمنشئ
- **متى يُضاف للطابور:**
  - عند تغيير حالة Deal (من Event Listener)
  - من `DealStatusChanged` event
- **الجداول المستخدمة:**
  - `deals` - الصفقات
  - `notifications` - الإشعارات

---

### 6. **`ImportDataJob`**
- **الملف:** `app/Jobs/ImportDataJob.php`
- **الوظيفة:**
  - استيراد البيانات من ملفات CSV/Excel
  - استيراد Leads، Contacts، أو Deals
- **متى يُضاف للطابور:**
  - عند رفع ملف استيراد من المستخدم
  - من واجهة الاستيراد
- **الجداول المستخدمة:**
  - `import_results` - نتائج الاستيراد
  - `leads` / `contacts` / `deals` - البيانات المستوردة

---

### 7. **`SendEmailCampaignJob`**
- **الملف:** `app/Jobs/SendEmailCampaignJob.php`
- **الوظيفة:**
  - إرسال حملات بريد إلكتروني جماعية
  - إرسال رسائل إلى قائمة من المستلمين
- **متى يُضاف للطابور:**
  - عند إرسال حملة بريد إلكتروني من `EmailCampaignController`
  - عند جدولة حملة بريد إلكتروني
- **الجداول المستخدمة:**
  - `email_campaigns` - الحملات البريدية
  - `email_accounts` - حسابات البريد الإلكتروني

---

## 🗄️ جداول قاعدة البيانات المستخدمة

### جداول الطابور (Queue Tables):
- **`jobs`** - المهام في الطابور (Laravel Queue)
- **`job_batches`** - مجموعات المهام
- **`failed_jobs`** - المهام الفاشلة

### جداول المهام المجدولة:
- **`erp_report_schedules`** - التقارير المجدولة
  - يحتوي على: `cron_expression`, `next_run_at`, `last_run_at`, `is_active`
- **`system_health`** - صحة النظام
- **`erp_recurring_invoices`** - الفواتير المتكررة
- **`erp_reorder_rules`** - قواعد إعادة الطلب

### جداول المهام في الطابور:
- **`erp_webhook_deliveries`** - عمليات تسليم Webhooks
  - يحتوي على: `status`, `attempts`, `response_code`, `delivered_at`
- **`import_results`** - نتائج الاستيراد
  - يحتوي على: `status`, `success_count`, `failed_count`, `error_log`
- **`workflows`** - تعريفات Workflows
- **`workflow_runs`** - سجل تنفيذ Workflows
- **`activities`** - الأنشطة
- **`deals`** - الصفقات
- **`email_campaigns`** - الحملات البريدية
- **`notifications`** - الإشعارات

---

## 📊 ملخص سريع

### `schedule:work` يشغل:
1. ✅ فحص تذكيرات الأنشطة (كل 5 دقائق)
2. ✅ مزامنة البريد الإلكتروني (كل 5 دقائق)
3. ✅ توليد التقارير المجدولة (كل دقيقة)
4. ✅ فحص صحة النظام (كل 5 دقائق)
5. ✅ إعادة محاولة Webhooks الفاشلة (كل 10 دقائق)
6. ✅ توليد الفواتير المتكررة (يومياً)
7. ✅ فحص قواعد إعادة الطلب (يومياً)

### `queue:work` يعالج:
1. ✅ إرسال Webhooks
2. ✅ تنفيذ Workflows
3. ✅ تصدير التقارير
4. ✅ إرسال تذكيرات الأنشطة
5. ✅ إرسال إشعارات الصفقات
6. ✅ استيراد البيانات
7. ✅ إرسال الحملات البريدية

---

## 🔍 كيفية التحقق من عمل المهام

### التحقق من المهام المجدولة:
```bash
php artisan schedule:list
```

### التحقق من المهام في الطابور:
```bash
# عرض المهام المعلقة
php artisan queue:work --once

# عرض المهام الفاشلة
php artisan queue:failed
```

### عرض سجلات المهام:
```bash
tail -f storage/logs/laravel.log | grep "Running scheduled command"
tail -f storage/logs/laravel.log | grep "Job"
```

---

## ⚠️ ملاحظات مهمة

1. **`schedule:work`** يجب أن يعمل دائماً في Production
2. **`queue:work`** يجب أن يعمل دائماً إذا كان لديك مهام في الطابور
3. المهام المجدولة تضيف مهام إلى الطابور، لذلك تحتاج كليهما
4. استخدم Supervisor أو NSSM في Production لإدارة العمليات تلقائياً

























