# كيفية استخدام Mention في الفرونت إند - الحل الصحيح

## 🔍 المشكلة

عند كتابة `@ali` في حقل `body`، لم يحدث شيء لأن:
1. الـ Backend يتوقع `@123` (رقم ID) وليس `@ali` (اسم)
2. الـ Frontend يحتاج تفعيل خاصية `enableMentions` في `RichTextEditor`

---

## ✅ الحل

### 1. تم تفعيل Mention في صفحة Notes

تم تحديث `ERPFrontend/src/pages/Notes/Notes.tsx` لإضافة:
```tsx
<RichTextEditor
  value={formData.body || ''}
  onChange={(value) => setFormData({ ...formData, body: value })}
  placeholder="Enter note content... (اكتب @ لذكر مستخدم)"
  className="dark:bg-gray-800"
  enableMentions={true}  // ✅ تم إضافته
/>
```

---

## 🎯 كيفية الاستخدام الصحيح

### الطريقة الصحيحة:

1. **اكتب `@` في حقل Body**
   - عند كتابة `@`، ستظهر قائمة منسدلة للمستخدمين

2. **اكتب اسم المستخدم أو البريد الإلكتروني**
   - مثال: `@ali` أو `@ahmed` أو `@example.com`
   - سيتم البحث تلقائياً في قائمة المستخدمين

3. **اختر المستخدم من القائمة**
   - استخدم الأسهم (↑↓) للتنقل
   - اضغط Enter أو انقر على المستخدم

4. **سيتم إدراج Mention تلقائياً**
   - سيتم إدراج `@{123}` (ID المستخدم) تلقائياً
   - لا تحتاج لكتابة ID يدوياً

---

## 📝 مثال عملي

### الخطوات:

1. **افتح صفحة Notes**
   - اضغط "Add Note"

2. **اختر Related Type و Related ID**
   - مثال: `deal` و `5`

3. **في حقل Body:**
   - اكتب: `مرحباً @`
   - ستظهر قائمة المستخدمين تلقائياً

4. **اكتب اسم المستخدم:**
   - مثال: `@ali`
   - سيتم البحث في قائمة المستخدمين

5. **اختر المستخدم:**
   - اضغط Enter أو انقر على المستخدم
   - سيتم إدراج `@{123}` تلقائياً

6. **اكمل النص:**
   ```
   مرحباً @{123}، يرجى مراجعة هذه الصفقة
   ```

7. **احفظ Note**
   - سيتم إرسال Request مع `@{123}` في الـ body
   - سيتم إرسال إشعار للمستخدم تلقائياً

---

## 🔄 كيف يعمل Mention في الفرونت إند

### 1. RichTextEditor مع enableMentions={true}

```tsx
<RichTextEditor
  enableMentions={true}  // تفعيل Mention
  value={body}
  onChange={setBody}
/>
```

### 2. عند كتابة @

- يتم اكتشاف `@` في النص
- يتم عرض `MentionAutocomplete` component
- يتم البحث في المستخدمين تلقائياً

### 3. MentionAutocomplete

- يبحث في المستخدمين باستخدام `userService.search()`
- يعرض قائمة المستخدمين المطابقة
- عند الاختيار، يتم إدراج `@{user_id}` تلقائياً

### 4. عند الحفظ

- يتم إرسال النص مع `@{123}` إلى الـ Backend
- الـ Backend يتحلل `@{123}` ويستخرج ID
- يتم إنشاء Mention وإرسال إشعار

---

## ⚠️ ملاحظات مهمة

### 1. لا تكتب ID يدوياً
   - ❌ `@123` - يعمل لكن ليس سهلاً
   - ✅ `@ali` ثم اختر من القائمة - أسهل وأفضل

### 2. MentionAutocomplete يحتاج API
   - يجب أن يكون `userService.search()` يعمل
   - Endpoint: `GET /api/users?search=ali`

### 3. التحقق من API

تأكد من وجود endpoint للبحث في المستخدمين:
```typescript
// في userService.ts
async search(query: string): Promise<{ data: User[] }> {
  const response = await api.get(this.endpoint, {
    params: { search: query, per_page: 10 },
  });
  return { data: response.data };
}
```

---

## 🐛 حل المشاكل

### المشكلة: لا تظهر قائمة المستخدمين عند كتابة @

**الحل:**
1. تأكد من `enableMentions={true}` في RichTextEditor
2. تأكد من وجود `userService.search()` في الكود
3. تأكد من أن API `/api/users?search=...` يعمل

### المشكلة: لا يتم إرسال إشعار

**الحل:**
1. تأكد من أن النص يحتوي على `@{123}` وليس `@ali`
2. تأكد من أن المستخدم موجود في نفس Tenant
3. تأكد من أن `queue:work` يعمل (لإرسال الإشعارات)

---

## 📊 مثال كود كامل

```tsx
// في صفحة Notes
const Notes = () => {
  const [formData, setFormData] = useState({
    body: '',
    noteable_type: 'deal',
    noteable_id: 5,
  });

  return (
    <RichTextEditor
      value={formData.body}
      onChange={(value) => setFormData({ ...formData, body: value })}
      enableMentions={true}  // ✅ مهم جداً
      placeholder="اكتب @ لذكر مستخدم"
    />
  );
};
```

---

## ✅ الخلاصة

1. **تم تفعيل Mention في صفحة Notes** ✅
2. **اكتب `@` ثم اسم المستخدم** ✅
3. **اختر من القائمة المنسدلة** ✅
4. **سيتم إدراج `@{id}` تلقائياً** ✅
5. **سيتم إرسال إشعار تلقائياً** ✅

---

**الآن جرب:**
1. افتح صفحة Notes
2. اضغط "Add Note"
3. اكتب `@` في حقل Body
4. اكتب اسم المستخدم (مثل `@ali`)
5. اختر من القائمة
6. احفظ Note
7. سيتم إرسال إشعار للمستخدم المذكور! 🎉

























