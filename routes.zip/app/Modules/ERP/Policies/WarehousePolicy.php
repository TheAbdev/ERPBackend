<?php

namespace App\Modules\ERP\Policies;

class WarehousePolicy extends ErpBasePolicy
{
    protected function getResourceName(): string
    {
        return 'warehouses';
    }
}
























