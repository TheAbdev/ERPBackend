<?php

namespace App\Modules\ECommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ECommerce\Models\ContentBlock;
use App\Modules\ECommerce\Models\Page;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class PageBuilderController extends Controller
{
    public function getBlockTypes(): JsonResponse
    {
        return response()->json([
            'data' => [
                ['type' => 'header', 'name' => 'Header', 'icon' => 'header', 'description' => 'Store header'],
                ['type' => 'footer', 'name' => 'Footer', 'icon' => 'footer', 'description' => 'Store footer'],
                ['type' => 'hero', 'name' => 'Hero', 'icon' => 'hero', 'description' => 'Hero section'],
                ['type' => 'banner', 'name' => 'Banner', 'icon' => 'banner', 'description' => 'Promotional banner'],
                ['type' => 'feature_grid', 'name' => 'Feature Grid', 'icon' => 'grid', 'description' => 'Feature list'],
                ['type' => 'testimonial', 'name' => 'Testimonial', 'icon' => 'quote', 'description' => 'Testimonials'],
                ['type' => 'promo_strip', 'name' => 'Promo Strip', 'icon' => 'promo', 'description' => 'Promo strip'],
                ['type' => 'products_grid', 'name' => 'Products Grid', 'icon' => 'products', 'description' => 'Products grid'],
                ['type' => 'text', 'name' => 'Text', 'icon' => 'text', 'description' => 'Text block'],
                ['type' => 'image', 'name' => 'Image', 'icon' => 'image', 'description' => 'Image block'],
                ['type' => 'button', 'name' => 'Button', 'icon' => 'button', 'description' => 'Button block'],
            ],
        ]);
    }

    public function getReusableBlocks(Request $request): JsonResponse
    {
        $this->authorize('viewAny', ContentBlock::class);

        $query = ContentBlock::query()
            ->where('tenant_id', $request->user()->tenant_id)
            ->where('is_reusable', true);

        if ($request->filled('store_id')) {
            $query->where('store_id', $request->input('store_id'));
        }

        return response()->json([
            'data' => $query->latest()->get(),
        ]);
    }

    public function createReusableBlock(Request $request): JsonResponse
    {
        $this->authorize('create', ContentBlock::class);

        $validated = $request->validate([
            'store_id' => ['nullable', 'exists:ecommerce_stores,id'],
            'type' => ['required', 'string'],
            'name' => ['required', 'string', 'max:255'],
            'content' => ['required', 'array'],
            'settings' => ['nullable', 'array'],
        ]);

        $block = ContentBlock::create([
            'tenant_id' => $request->user()->tenant_id,
            'store_id' => $validated['store_id'] ?? null,
            'type' => $validated['type'],
            'name' => $validated['name'],
            'content' => $validated['content'],
            'settings' => $validated['settings'] ?? [],
            'is_reusable' => true,
        ]);

        return response()->json([
            'message' => 'Reusable block created successfully.',
            'data' => $block,
        ], 201);
    }

    public function savePageContent(Request $request, Page $page): JsonResponse
    {
        $this->authorize('update', $page);

        $validated = $request->validate([
            'blocks' => ['required', 'array'],
        ]);

        if (Schema::hasColumn('ecommerce_pages', 'draft_content')) {
            $page->draft_content = ['blocks' => $validated['blocks']];
        } else {
            $page->content = ['blocks' => $validated['blocks']];
        }

        $page->is_published = false;
        $page->save();

        return response()->json([
            'message' => 'Page saved successfully.',
            'data' => $page,
        ]);
    }

    public function publishPageContent(Request $request, Page $page): JsonResponse
    {
        $this->authorize('update', $page);

        $validated = $request->validate([
            'blocks' => ['required', 'array'],
        ]);

        if (Schema::hasColumn('ecommerce_pages', 'published_content')) {
            $page->published_content = ['blocks' => $validated['blocks']];
        } else {
            $page->content = ['blocks' => $validated['blocks']];
        }

        $page->is_published = true;
        $page->save();

        return response()->json([
            'message' => 'Page published successfully.',
            'data' => $page,
        ]);
    }
}
