<?php

namespace App\Models\Modules\ERP\Models;

use Illuminate\Database\Eloquent\Model;

class CreditNoteItem extends Model
{
    //
}
